﻿namespace BlankApp.Modules.ModuleA.Models
{
    /// <summary>
    /// 注意区分每个模块中的 Models 和 BlankApp.Doamin 中的 Entities 之间的区别
    /// </summary>
    internal class Todo
    {
    }
}