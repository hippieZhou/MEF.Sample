﻿using System.Windows.Controls;

namespace BlankApp.Modules.ModuleA.Views
{
    /// <summary>
    /// Interaction logic for SubView
    /// </summary>
    public partial class SubView : UserControl
    {
        public SubView()
        {
            InitializeComponent();
        }
    }
}