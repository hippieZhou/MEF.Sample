﻿using System.Windows.Controls;

namespace BlankApp.Modules.ModuleA.Views
{
    public partial class MainView : UserControl
    {
        public MainView()
        {
            InitializeComponent();
        }
    }
}