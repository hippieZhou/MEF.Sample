﻿namespace BlankApp.Modules.ModuleB.Models
{
    public class PersonDto
    {
        public string Name { get; set; }
    }
}
