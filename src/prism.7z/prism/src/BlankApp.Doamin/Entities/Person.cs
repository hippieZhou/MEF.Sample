﻿namespace BlankApp.Doamin.Entities
{
    public class Person: AuditableEntity
    {
        public string Name { get; set; }
    }
}
