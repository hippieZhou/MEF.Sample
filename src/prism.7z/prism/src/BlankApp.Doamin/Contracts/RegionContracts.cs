﻿namespace BlankApp.Doamin.Contracts
{
    public class RegionContracts
    {
        public const string TopContentRegion = "TopContentRegion";
        public const string MainContentRegion = "MainContentRegion";
        public const string ChildContentRegion = "ChildContentRegion";
    }
}
